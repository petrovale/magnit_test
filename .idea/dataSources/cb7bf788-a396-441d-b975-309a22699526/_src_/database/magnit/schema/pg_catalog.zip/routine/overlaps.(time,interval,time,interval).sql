create function "overlaps"(time without time zone, interval, time without time zone, interval) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))
$$;
